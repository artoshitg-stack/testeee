package app.aerolounge

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.bluetooth.BluetoothAdapter
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.provider.Settings
import android.text.InputType
import android.webkit.JavascriptInterface
import android.webkit.PermissionRequest
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.EditText
import org.json.JSONObject

class MainActivity : Activity() {
    private lateinit var web: WebView
    private lateinit var bt: BtChat
    private var fileCb: ValueCallback<Array<Uri>>? = null
    private var pendingPerm: PermissionRequest? = null
    private val prefs by lazy { getSharedPreferences("aero", MODE_PRIVATE) }

    companion object {
        const val BT_PAGE = "file:///android_asset/bt.html"
        const val REQ_FILE = 1
        const val REQ_PERM = 2
        const val REQ_BT = 3
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.parseColor("#101C33")
        window.navigationBarColor = Color.parseColor("#0C1629")
        web = WebView(this)
        web.setBackgroundColor(Color.parseColor("#101C33"))
        setContentView(web)

        val s = web.settings
        s.javaScriptEnabled = true
        s.domStorageEnabled = true
        s.mediaPlaybackRequiresUserGesture = false
        s.mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW

        bt = BtChat(this) { ev, data ->
            js("window.onBT&&window.onBT(" + JSONObject.quote(ev) + "," + JSONObject.quote(data) + ")")
        }
        web.addJavascriptInterface(Bridge(), "AeroApp")
        web.setDownloadListener { url, _, _, _, _ ->
            try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) } catch (_: Exception) {}
        }
        web.webViewClient = object : WebViewClient() {
            override fun onReceivedError(v: WebView, r: WebResourceRequest, e: WebResourceError) {
                // сервер недоступен: открываем локальную страницу с Bluetooth-чатом
                if (r.isForMainFrame && !r.url.toString().startsWith("file:")) v.loadUrl("$BT_PAGE?err=1")
            }
        }
        web.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(w: WebView, cb: ValueCallback<Array<Uri>>, p: FileChooserParams): Boolean {
                fileCb?.onReceiveValue(null)
                fileCb = cb
                val audioCapture = p.isCaptureEnabled && p.acceptTypes.any { it.startsWith("audio") }
                val intent = if (audioCapture) Intent(MediaStore.Audio.Media.RECORD_SOUND_ACTION) else p.createIntent()
                return try {
                    startActivityForResult(intent, REQ_FILE); true
                } catch (e: Exception) {
                    fileCb = null; cb.onReceiveValue(null); false
                }
            }

            override fun onPermissionRequest(r: PermissionRequest) {
                runOnUiThread {
                    if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
                        r.grant(r.resources)
                    } else {
                        pendingPerm = r
                        requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), REQ_PERM)
                    }
                }
            }
        }
        ensureBtPerm()
        openServer()
    }

    private fun js(code: String) = runOnUiThread { web.evaluateJavascript(code, null) }

    private fun ensureBtPerm() {
        if (Build.VERSION.SDK_INT >= 31 &&
            checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.BLUETOOTH_CONNECT), REQ_BT)
        }
    }

    private fun openServer() {
        val u = prefs.getString("server", null)
        if (u == null) askServer(true) else web.loadUrl(u)
    }

    private fun askServer(first: Boolean) {
        val et = EditText(this)
        et.hint = "http://192.168.0.5:3000"
        et.setText(prefs.getString("server", "http://"))
        et.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
        val b = AlertDialog.Builder(this)
            .setTitle("Адрес сервера AeroLounge")
            .setMessage("Адрес из окна сервера. Телефон должен быть в той же сети.")
            .setView(et)
            .setCancelable(!first)
            .setPositiveButton("Подключиться") { _, _ -> setServer(et.text.toString()) }
            .setNeutralButton("Только Bluetooth") { _, _ -> web.loadUrl(BT_PAGE) }
        if (!first) b.setNegativeButton("Отмена", null)
        b.show()
    }

    private fun setServer(raw: String) {
        var u = raw.trim()
        if (u.isEmpty()) return
        if (!u.startsWith("http")) u = "http://$u"
        u = u.trimEnd('/')
        prefs.edit().putString("server", u).apply()
        web.loadUrl(u)
    }

    private fun safe(block: () -> Unit) { try { block() } catch (_: Exception) {} }

    /** Мост JS ↔ Android. Доступен как window.AeroApp на странице сервера и в локальной странице Bluetooth. */
    inner class Bridge {
        @JavascriptInterface fun openBt() = runOnUiThread { web.loadUrl(BT_PAGE) }
        @JavascriptInterface fun openServer() = runOnUiThread { this@MainActivity.openServer() }
        @JavascriptInterface fun getServer(): String = prefs.getString("server", "") ?: ""
        @JavascriptInterface fun setServer(u: String) = runOnUiThread { this@MainActivity.setServer(u) }
        @JavascriptInterface fun askServer() = runOnUiThread { this@MainActivity.askServer(false) }
        @JavascriptInterface fun requestPerm() = runOnUiThread { ensureBtPerm() }
        @JavascriptInterface fun btSupported(): Boolean = bt.supported()
        @JavascriptInterface fun btEnabled(): Boolean = bt.enabled()
        @JavascriptInterface fun btDevices(): String = bt.devices()
        @JavascriptInterface fun btStart() = safe { bt.listen() }
        @JavascriptInterface fun btConnect(addr: String) = safe { bt.connect(addr) }
        @JavascriptInterface fun btSend(line: String) = bt.send(line)
        @JavascriptInterface fun btDisconnect() = bt.close()
        @JavascriptInterface fun btState(): String = bt.state
        @JavascriptInterface fun btDiscoverable() = runOnUiThread {
            safe { startActivity(Intent(BluetoothAdapter.ACTION_REQUEST_DISCOVERABLE)
                .putExtra(BluetoothAdapter.EXTRA_DISCOVERABLE_DURATION, 300)) }
        }
        @JavascriptInterface fun btEnable() = runOnUiThread {
            safe { startActivity(Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE)) }
        }
        @JavascriptInterface fun btSettings() = runOnUiThread {
            safe { startActivity(Intent(Settings.ACTION_BLUETOOTH_SETTINGS)) }
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ_FILE) {
            fileCb?.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(resultCode, data))
            fileCb = null
        }
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, res: IntArray) {
        super.onRequestPermissionsResult(code, perms, res)
        val ok = res.isNotEmpty() && res[0] == PackageManager.PERMISSION_GRANTED
        if (code == REQ_PERM) {
            pendingPerm?.let { if (ok) it.grant(it.resources) else it.deny() }
            pendingPerm = null
        }
        if (code == REQ_BT) js("window.onBT&&window.onBT('perm','" + (if (ok) "ok" else "no") + "')")
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        val onServer = web.url?.startsWith("file:") != true
        if (onServer && web.canGoBack()) web.goBack() else super.onBackPressed()
    }

    override fun onDestroy() {
        bt.shutdown()
        super.onDestroy()
    }
}
