package app.aerolounge

import android.annotation.SuppressLint
import android.app.Activity
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothServerSocket
import android.bluetooth.BluetoothSocket
import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.OutputStream
import java.util.UUID
import java.util.concurrent.Executors

/**
 * Чат 1-на-1 по Bluetooth Classic (RFCOMM). Телефоны должны быть связаны (спарены) в настройках Bluetooth.
 * Одно устройство ждёт подключения (listen), другое подключается (connect). Сообщения — строки JSON.
 */
@SuppressLint("MissingPermission")
class BtChat(act: Activity, private val emit: (String, String) -> Unit) {
    private val uuid: UUID = UUID.fromString("5a1c0e4e-7b1d-4c36-9d0c-3a9d6e0b7a11")
    private val adapter: BluetoothAdapter? =
        (act.getSystemService(Context.BLUETOOTH_SERVICE) as? BluetoothManager)?.adapter
    private val io = Executors.newCachedThreadPool()
    private val writer = Executors.newSingleThreadExecutor()

    @Volatile private var sock: BluetoothSocket? = null
    @Volatile private var out: OutputStream? = null
    @Volatile private var server: BluetoothServerSocket? = null
    @Volatile private var listening = false

    @Volatile var state: String = "idle"
        private set

    fun supported(): Boolean = adapter != null
    fun enabled(): Boolean = try { adapter?.isEnabled == true } catch (e: SecurityException) { false }

    private fun set(s: String) { state = s; emit("state", s) }

    /** Список уже связанных (спаренных) устройств. */
    fun devices(): String {
        val arr = JSONArray()
        try {
            adapter?.bondedDevices?.forEach { d ->
                arr.put(JSONObject().put("name", d.name ?: d.address).put("address", d.address))
            }
        } catch (e: SecurityException) { /* нет разрешения BLUETOOTH_CONNECT */ }
        return arr.toString()
    }

    /** Ждать входящего подключения. */
    fun listen() {
        val a = adapter ?: return
        if (listening || !enabled()) return
        listening = true
        io.execute {
            try {
                server = a.listenUsingRfcommWithServiceRecord("AeroLounge", uuid)
                if (state == "idle" || state.startsWith("error") || state == "disconnected") set("listening")
                while (listening) {
                    val s = server?.accept() ?: break
                    attach(s)
                }
            } catch (e: Exception) {
                if (listening) set("error:" + (e.message ?: "listen"))
            } finally {
                listening = false
                try { server?.close() } catch (_: Exception) {}
            }
        }
    }

    /** Подключиться к связанному устройству по MAC-адресу. */
    fun connect(addr: String) {
        val a = adapter ?: return
        set("connecting")
        io.execute {
            try {
                a.cancelDiscovery()
                val s = a.getRemoteDevice(addr).createRfcommSocketToServiceRecord(uuid)
                s.connect()
                attach(s)
            } catch (e: Exception) {
                set("error:" + (e.message ?: "connect"))
            }
        }
    }

    private fun attach(s: BluetoothSocket) {
        close(false)
        sock = s
        out = s.outputStream
        val who: String = try { s.remoteDevice.name ?: s.remoteDevice.address } catch (e: Exception) { "устройство" }
        set("connected:$who")
        io.execute {
            try {
                val r = BufferedReader(InputStreamReader(s.inputStream, Charsets.UTF_8))
                while (true) {
                    val line = r.readLine() ?: break
                    if (line.isNotBlank()) emit("msg", line)
                }
            } catch (_: Exception) {}
            if (sock === s) { close(false); set("disconnected") }
        }
    }

    fun send(line: String) {
        writer.execute {
            try {
                val o = out
                if (o == null) {
                    emit("state", "error:нет соединения")
                } else {
                    o.write((line.replace("\n", " ") + "\n").toByteArray(Charsets.UTF_8))
                    o.flush()
                }
            } catch (e: Exception) {
                emit("state", "error:" + (e.message ?: "send"))
            }
        }
    }

    fun close(notify: Boolean = true) {
        try { sock?.close() } catch (_: Exception) {}
        sock = null
        out = null
        if (notify) set("disconnected")
    }

    fun shutdown() {
        listening = false
        try { server?.close() } catch (_: Exception) {}
        close(false)
    }
}
